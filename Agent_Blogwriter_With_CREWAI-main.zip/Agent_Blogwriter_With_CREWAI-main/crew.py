
from crewai import Crew, Process
from agents import blog_researcher, blog_writer
from tasks import research_task, write_task

crew = Crew(
    agents=[blog_researcher, blog_writer],
    tasks=[research_task, write_task],

    process=Process.sequential,
    memory=True,
    verbose=True,
)

result = crew.kickoff(
    inputs={
        "topic": "AI-Assisted Development Tutorial – Multi-Agent Coding & Deployment with TRAE IDE"
    }
)

print(result)